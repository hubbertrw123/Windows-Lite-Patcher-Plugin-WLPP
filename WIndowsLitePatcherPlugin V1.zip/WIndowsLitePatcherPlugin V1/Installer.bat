@echo off
title Windows Optimizer & Toolkit Installer

:: ======================================================
:: AUTO ELEVATE
:: ======================================================
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator access...
    powershell -Command "Start-Process '%~f0' -Verb runAs"
    exit /b
)

cls
echo ================================================
echo   WINDOWS Lite Plugins + TOOLKIT SETUP
echo ================================================
echo.

:: ======================================================
:: PATHS
:: ======================================================
set installDir=%USERPROFILE%\Windows-Toolkit
set zipfile=%~dp0Toolkit.zip

echo Installing to: %installDir%
echo.

:: ======================================================
:: EXTRACT ZIP
:: ======================================================
echo Extracting Toolkit.zip...
powershell -Command "Expand-Archive -Force '%zipfile%' '%installDir%'"

if %errorLevel% neq 0 (
    echo.
    echo ❌ Extraction FAILED!
    echo Pastikan file Toolkit.zip tidak corrupt!
    pause
    exit /b
)

echo Extract OK!
echo.

:: ======================================================
:: OPTIMIZATION
:: ======================================================
echo Applying optimization...

:: Power plan
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 >nul
powercfg /setactive e9a42b02-d5df-448d-aa00-03f14749eb61

:: Network
netsh int tcp set global autotuninglevel=normal
netsh int tcp set global dca=enabled
netsh int tcp set global chimney=enabled
netsh int tcp set global netdma=enabled

:: Background apps off
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f

:: Clear temp
del /s /q "%temp%\*.*" >nul 2>&1
del /s /q "C:\Windows\Temp\*.*" >nul 2>&1

:: DNS
ipconfig /flushdns >nul

echo Optimization done!
echo.

:: ======================================================
:: CREATE DESKTOP SHORTCUT ONLY FOR MAIN.BAT
:: ======================================================
echo Creating desktop shortcut...

set shortcut=%USERPROFILE%\Desktop\Windows Toolkit.lnk
set target=%installDir%\MAIN.bat

powershell -Command ^
"$s=(New-Object -COM WScript.Shell).CreateShortcut('%shortcut%'); ^
$s.TargetPath='%target%'; ^
$s.WorkingDirectory='%installDir%'; ^
$s.IconLocation='%SystemRoot%\system32\imageres.dll,30'; ^
$s.Save()"

echo Shortcut created!
echo.

:: ======================================================
:: HIDE MODULES & TOOLS so they don't appear anywhere
:: ======================================================
attrib +h +s "%installDir%\MODULES"
attrib +h +s "%installDir%\TOOLS"

echo Modules and Tools are hidden.
echo.

:: ======================================================
:: RUN TOOLKIT
:: ======================================================
echo Launching Toolkit in background...
start "" /min cmd /c "%installDir%\MAIN.bat"

echo.
echo restart needed for apply scripts.
echo Your Computer will restarted from 10 seconds...
timeout /t 10 >nul

echo Restarting now...
shutdown /r /f /t 0
exit